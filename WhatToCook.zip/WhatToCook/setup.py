from setuptools import setup

setup(name='whattocook',
      version='0.1',
      description='Rwandan Recipe',
      author='Asif Mahmud',
      license='MIT',
      packages=['whattocook'],
      )
